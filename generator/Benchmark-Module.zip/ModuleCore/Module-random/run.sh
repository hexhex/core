
echo "process: Module-random-20-5-1-10-0-10-10-d10"
cd Module-random-20-5-1-10-0-10-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-10-10-d15"
cd Module-random-20-5-1-10-0-10-10-d15
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-10-10-d20"
cd Module-random-20-5-1-10-0-10-10-d20
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-10-15-d10"
cd Module-random-20-5-1-10-0-10-15-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-10-20-d10"
cd Module-random-20-5-1-10-0-10-20-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-10-25-d10"
cd Module-random-20-5-1-10-0-10-25-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-10-5-d10"
cd Module-random-20-5-1-10-0-10-5-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-15-10-d10"
cd Module-random-20-5-1-10-0-15-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-20-10-d10"
cd Module-random-20-5-1-10-0-20-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-10-0-5-10-d10"
cd Module-random-20-5-1-10-0-5-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-15-0-10-10-d10"
cd Module-random-20-5-1-15-0-10-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-1-5-0-10-10-d10"
cd Module-random-20-5-1-5-0-10-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-10-10-d10"
cd Module-random-20-5-2-10-10-10-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-10-10-d15"
cd Module-random-20-5-2-10-10-10-10-d15
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-10-10-d20"
cd Module-random-20-5-2-10-10-10-10-d20
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-10-15-d10"
cd Module-random-20-5-2-10-10-10-15-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-10-20-d10"
cd Module-random-20-5-2-10-10-10-20-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-10-25-d10"
cd Module-random-20-5-2-10-10-10-25-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-10-5-d10"
cd Module-random-20-5-2-10-10-10-5-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-15-10-d10"
cd Module-random-20-5-2-10-10-15-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-20-10-d10"
cd Module-random-20-5-2-10-10-20-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-10-10-5-10-d10"
cd Module-random-20-5-2-10-10-5-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-15-10-10-10-d10"
cd Module-random-20-5-2-15-10-10-10-d10
./run.sh
cd ..
echo "process: Module-random-20-5-2-5-10-10-10-d10"
cd Module-random-20-5-2-5-10-10-10-d10
./run.sh
cd ..
