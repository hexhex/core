
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i1.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i1-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i1.log 1>/dev/null
echo "1 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i2.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i2-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i2.log 1>/dev/null
echo "2 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i3.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i3-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i3.log 1>/dev/null
echo "3 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i4.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i4-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i4.log 1>/dev/null
echo "4 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i5.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i5-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i5.log 1>/dev/null
echo "5 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i6.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i6-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i6.log 1>/dev/null
echo "6 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i7.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i7-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i7.log 1>/dev/null
echo "7 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i8.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i8-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i8.log 1>/dev/null
echo "8 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i9.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i9-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i9.log 1>/dev/null
echo "9 instances(s) processed"
(ulimit -v 1048576 ; /usr/bin/time --verbose -o time-Module-diamond-20-5-1-10-0-10-5-i10.log dlvhex --mlp --num=100 --verbose=128 Module-diamond-20-5-1-10-0-10-5-i10-*.mlp) 2>stats-Module-diamond-20-5-1-10-0-10-5-i10.log 1>/dev/null
echo "10 instances(s) processed"
