
echo "process: Module-line-20-5-1-10-0-10-10"
cd Module-line-20-5-1-10-0-10-10
./run.sh
cd ..
echo "process: Module-line-20-5-1-10-0-10-15"
cd Module-line-20-5-1-10-0-10-15
./run.sh
cd ..
echo "process: Module-line-20-5-1-10-0-10-20"
cd Module-line-20-5-1-10-0-10-20
./run.sh
cd ..
echo "process: Module-line-20-5-1-10-0-10-25"
cd Module-line-20-5-1-10-0-10-25
./run.sh
cd ..
echo "process: Module-line-20-5-1-10-0-10-5"
cd Module-line-20-5-1-10-0-10-5
./run.sh
cd ..
echo "process: Module-line-20-5-1-10-0-15-10"
cd Module-line-20-5-1-10-0-15-10
./run.sh
cd ..
echo "process: Module-line-20-5-1-10-0-20-10"
cd Module-line-20-5-1-10-0-20-10
./run.sh
cd ..
echo "process: Module-line-20-5-1-10-0-5-10"
cd Module-line-20-5-1-10-0-5-10
./run.sh
cd ..
echo "process: Module-line-20-5-1-15-0-10-10"
cd Module-line-20-5-1-15-0-10-10
./run.sh
cd ..
echo "process: Module-line-20-5-1-5-0-10-10"
cd Module-line-20-5-1-5-0-10-10
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-10-10"
cd Module-line-20-5-2-10-10-10-10
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-10-15"
cd Module-line-20-5-2-10-10-10-15
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-10-20"
cd Module-line-20-5-2-10-10-10-20
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-10-25"
cd Module-line-20-5-2-10-10-10-25
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-10-5"
cd Module-line-20-5-2-10-10-10-5
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-15-10"
cd Module-line-20-5-2-10-10-15-10
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-20-10"
cd Module-line-20-5-2-10-10-20-10
./run.sh
cd ..
echo "process: Module-line-20-5-2-10-10-5-10"
cd Module-line-20-5-2-10-10-5-10
./run.sh
cd ..
echo "process: Module-line-20-5-2-15-10-10-10"
cd Module-line-20-5-2-15-10-10-10
./run.sh
cd ..
echo "process: Module-line-20-5-2-5-10-10-10"
cd Module-line-20-5-2-5-10-10-10
./run.sh
cd ..
