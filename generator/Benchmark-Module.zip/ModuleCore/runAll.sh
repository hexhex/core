#!/bin/bash
for i in Module* 
do 
	cd $i
	echo "process $i"
	./run.sh
	cd ..
done
