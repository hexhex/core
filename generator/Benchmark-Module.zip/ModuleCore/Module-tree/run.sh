
echo "process: Module-tree-20-5-1-10-0-10-10-b2"
cd Module-tree-20-5-1-10-0-10-10-b2
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-10-10-b3"
cd Module-tree-20-5-1-10-0-10-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-10-10-b5"
cd Module-tree-20-5-1-10-0-10-10-b5
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-10-15-b3"
cd Module-tree-20-5-1-10-0-10-15-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-10-20-b3"
cd Module-tree-20-5-1-10-0-10-20-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-10-25-b3"
cd Module-tree-20-5-1-10-0-10-25-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-10-5-b3"
cd Module-tree-20-5-1-10-0-10-5-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-15-10-b3"
cd Module-tree-20-5-1-10-0-15-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-20-10-b3"
cd Module-tree-20-5-1-10-0-20-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-10-0-5-10-b3"
cd Module-tree-20-5-1-10-0-5-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-15-0-10-10-b3"
cd Module-tree-20-5-1-15-0-10-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-1-5-0-10-10-b3"
cd Module-tree-20-5-1-5-0-10-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-10-10-b2"
cd Module-tree-20-5-2-10-10-10-10-b2
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-10-10-b3"
cd Module-tree-20-5-2-10-10-10-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-10-10-b5"
cd Module-tree-20-5-2-10-10-10-10-b5
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-10-15-b3"
cd Module-tree-20-5-2-10-10-10-15-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-10-20-b3"
cd Module-tree-20-5-2-10-10-10-20-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-10-25-b3"
cd Module-tree-20-5-2-10-10-10-25-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-10-5-b3"
cd Module-tree-20-5-2-10-10-10-5-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-15-10-b3"
cd Module-tree-20-5-2-10-10-15-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-20-10-b3"
cd Module-tree-20-5-2-10-10-20-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-10-10-5-10-b3"
cd Module-tree-20-5-2-10-10-5-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-15-10-10-10-b3"
cd Module-tree-20-5-2-15-10-10-10-b3
./run.sh
cd ..
echo "process: Module-tree-20-5-2-5-10-10-10-b3"
cd Module-tree-20-5-2-5-10-10-10-b3
./run.sh
cd ..
